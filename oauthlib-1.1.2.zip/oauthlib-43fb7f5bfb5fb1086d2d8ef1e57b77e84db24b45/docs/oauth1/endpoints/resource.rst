Resource authorization
----------------------

.. autoclass:: oauthlib.oauth1.ResourceEndpoint
    :members:
