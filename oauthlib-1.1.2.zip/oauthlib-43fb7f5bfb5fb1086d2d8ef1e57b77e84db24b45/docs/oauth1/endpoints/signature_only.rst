Signature Only
--------------

.. autoclass:: oauthlib.oauth1.SignatureOnlyEndpoint
    :members:
