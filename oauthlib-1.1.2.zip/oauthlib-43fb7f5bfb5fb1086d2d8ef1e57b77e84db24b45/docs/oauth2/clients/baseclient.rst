Base Client
-----------

.. autoclass:: oauthlib.oauth2.Client
    :members:
