BackendApplicationClient
------------------------

.. autoclass:: oauthlib.oauth2.BackendApplicationClient
    :members:
