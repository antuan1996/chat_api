Resource Owner Password Credentials Grant
-----------------------------------------

.. autoclass:: oauthlib.oauth2.ResourceOwnerPasswordCredentialsGrant
    :members:
